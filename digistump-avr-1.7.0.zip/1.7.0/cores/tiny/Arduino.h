#ifndef Arduino_h
#define Arduino_h

#include <WProgram.h>

#define NOT_AN_INTERRUPT -1
#endif
