WiiClassicController - Library for the WCC for the Digispark / Arduino

Copyright 2017 Eduardo Flores - Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License 
http://eduardofv.com/2017/02/06/wii-classic-controller-usb-arduino/
https://github.com/eduardofv/ArduinoWiiClassicController

Based on ArduinoNunchuck by Gabriel Bianconi
https://github.com/eduardofv/DigistumpArduino/tree/master/digistump-avr/libraries/Nunchuk
Project URL: http://www.gabrielbianconi.com/projects/arduinonunchuk/


Based on the following resources:
 - http://www.windmeadow.com/node/42
 - http://todbot.com/blog/2008/02/18/wiichuck-wii-nunchuck-adapter-available/
 - http://wiibrew.org/wiki/Wiimote/Extension_Controllers
 - http://www.instructables.com/id/USB-Wii-Classic-Controller/step9/Reading-the-Wii-Classic-Controller/
 - http://wiibrew.org/wiki/Wiimote/Extension_Controllers/Classic_Controller


