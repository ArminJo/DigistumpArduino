//For compatibility with older programs
#include "Arduino.h"